/*1*/
CREATE TABLE productosVendidos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigoProducto INT,
    producto VARCHAR(30),
    cantidadTotal INT
);
/*2*/
CREATE PROCEDURE productos_vendidos(IN codigo INT, OUT cantidad INT)
BEGIN
    DECLARE total INT;
    
    SELECT SUM(cantidad) INTO total
    FROM detalle_venta
    WHERE codigo_producto = codigo;
    
    SET cantidad = IF(total IS NULL, 0, total);
END;


/*esto es para ver si jala*/

SET @cantidad_total = 0;

CALL estadisticas_productos_vendidos(2, @cantidad_total);

SELECT @cantidad_total AS total_cantidad_vendida;


/*3*/
DELIMITER //


DELIMITER$$

DROP TRIGGER IF EXISTS insertarVenta$$

CREATE TRIGGER insertarVenta
AFTER INSERT ON detalle_venta
FOR EACH ROW
BEGIN
    DECLARE totalVenta int;
    DECLARE productonombre VARCHAR(55);
    CALL productos_vendidos(new.codigo_producto, totalVenta);

    select nombre INTO prodNom
    from producto
    where id = new.codigo_producto;

    insert into productosVendidos(codigo_producto, producto, cantidad_total) VALUES
    (new.codigoProducto, productonombre, total_vend);
 
END$$

DELIMITER ;




/*4*/

CREATE TABLE alumnosEliminados(
id int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
idAlumnos int,
nombreAlumno VARCHAR(30),
fechaHora DATE
);

/*5*/




/*pa borrar algo si se ocupa*/
DROP Procedure productos_vendidos;
























create table productos_vendidos(
    id int PRIMARY KEY AUTO_INCREMENT,
    codigo_producto int,
    producto varchar(30),
    cantidad_total int
)



DELIMITER$$

DROP PROCEDURE IF EXISTS estadísticas_productos_vendidos$$

CREATE PROCEDURE estadísticas_productos_vendidos (IN codigo INT,OUT total INT)
BEGIN
   

    SELECT SUM(cantidad) INTO total
    FROM detalle_venta
    WHERE id_producto = codigo;
END$$
DELIMITER ;




DELIMITER$$

DROP TRIGGER IF EXISTS insertarVentat$$

CREATE TRIGGER insertarVenta
AFTER INSERT ON detalle_venta
FOR EACH ROW
BEGIN
    DECLARE totalVenta int;
    DECLARE productonombre VARCHAR(55);
    CALL estadísticas_productos_vendidos(new.id_producto, totalVenta);

    select nombre INTO productonombre
    from producto
    where id = new.id_producto;

    insert into productos_vendidos(codigo_producto, producto, cantidad_total) VALUES
    (new.id_producto, prodnombre, totalVenta);
 
END$$


DELIMITER ;


insert into detalle_venta(id, cantidad, id_producto, id_venta) VALUES
(2, 3, 3, 2);


insert into detalle_venta(id, cantidad, id_producto, id_venta) VALUES
(9, 3, 2, 2);







create table alumnos_eliminados(
    id int PRIMARY KEY AUTO_INCREMENT,
    id_alumno int,
    nombre_alumno VARCHAR(55),
    fecha_hora date
)





DELIMITER $$

drop TRIGGER if EXISTS dropalumnos$$

CREATE TRIGGER dropalumnos
after delete on alumnos
FOR EACH ROW
BEGIN
    insert into alumnos_eliminados(id_alumno, nombre_alumno, fecha_hora) VALUES
    (old.id, old.nombre, now());

END$$


DELIMITER ;


CALL estadísticas_productos_vendidos(1, @total);
SELECT @total;






DELETE FROM alumnos 
WHERE id=3